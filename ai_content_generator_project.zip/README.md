
# AI Content Generation Agent

यह एक Python ऐप है जो GPT-4 का उपयोग करके मल्टी-लैंग्विज कंटेंट जनरेट करता है। आप इसे ब्लॉग, वीडियो स्क्रिप्ट, सोशल मीडिया पोस्ट, और अन्य प्रकार के कंटेंट के लिए उपयोग कर सकते हैं।

## कैसे इस्तेमाल करें

1. `requirements.txt` में दिए गए पैकेज इंस्टॉल करें:
    ```bash
    pip install -r requirements.txt
    ```

2. अपनी OpenAI API Key सेट करें (आप इसे `.env` या सीधे कोड में सेट कर सकते हैं):
    ```python
    openai.api_key = "आपकी_API_KEY"
    ```

3. ऐप को रन करें:
    ```bash
    python content_generation_agent.py
    ```

## वैरिएंट्स

- कंटेंट टाइप: blog, video script, social media, email, product, seo
- भाषा: हिंदी, अंग्रेजी, स्पैनिश, फ्रेंच, और बहुत कुछ।

