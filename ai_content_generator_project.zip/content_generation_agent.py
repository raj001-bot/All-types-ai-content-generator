
import openai
import os

def generate_content(prompt, content_type="blog", language="Hindi"):
    system_prompt = f"You are a professional content writer. Please write a '{content_type}' type of content in {language}."

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
    )

    return response['choices'][0]['message']['content']

def main():
    print("\n🔵 कंटेंट जनरेशन AI एजेंट में आपका स्वागत है!")

    content_type = input("\nआप किस प्रकार का कंटेंट जनरेट करना चाहते हैं? (blog/video script/social media/email/product/seo): ").strip().lower()
    topic = input("\nकृपया टॉपिक या कीवर्ड लिखें: ").strip()
    language = input("\nकृपया आउटपुट की भाषा बताएं (जैसे: Hindi, English, Spanish, French, etc.): ").strip()

    print("\n⏳ कंटेंट जनरेट किया जा रहा है...\n")
    content = generate_content(topic, content_type, language)

    print("\n✅ जनरेट किया गया कंटेंट:\n")
    print("-" * 50)
    print(content)
    print("-" * 50)

    save = input("\nक्या आप इसे फाइल में सेव करना चाहेंगे? (yes/no): ").strip().lower()
    if save == "yes":
        filename = input("फाइल का नाम लिखें (जैसे: content.txt): ").strip()
        with open(filename, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"\n💾 कंटेंट '{filename}' में सेव कर लिया गया है।")

if __name__ == "__main__":
    openai.api_key = os.getenv("OPENAI_API_KEY")  # या आप अपनी API Key यहाँ सीधे दे सकते हैं
    main()
